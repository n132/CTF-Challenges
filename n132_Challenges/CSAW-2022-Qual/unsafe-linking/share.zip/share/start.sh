/etc/init.d/xinetd start && sleep infinity;

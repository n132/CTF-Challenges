cat ./logo && timeout 120 ./chal
